
# Documentação do Sistema de Gestão

**Última atualização:** 20/12/2024

## 📋 Índice

1. [Visão Geral](#visão-geral)
2. [Estrutura do Projeto](#estrutura-do-projeto)
3. [Tecnologias Utilizadas](#tecnologias-utilizadas)
4. [Funcionalidades](#funcionalidades)
5. [Autenticação e Permissões](#autenticação-e-permissões)
6. [Componentes](#componentes)
7. [Páginas](#páginas)
8. [Configurações](#configurações)
9. [Padronizações de Interface](#padronizações-de-interface)

---

## 🎯 Visão Geral

Sistema de Gestão Empresarial desenvolvido em React + TypeScript com Firebase como backend. O sistema oferece controle completo de acesso baseado em permissões, gerenciamento de usuários e módulos especializados para diferentes áreas da empresa.

---

## 📁 Estrutura do Projeto

```
├── public/
│   └── favicon.svg                    # Ícone da aplicação
│
├── src/
│   ├── components/                    # Componentes reutilizáveis
│   │   ├── FirebaseStatus.tsx        # Verificação de status do Firebase
│   │   ├── Layout.tsx                # Layout principal com navegação
│   │   └── ProtectedRoute.tsx        # HOC para proteção de rotas
│   │
│   ├── config/                        # Configurações
│   │   └── firebase.ts               # Configuração do Firebase
│   │
│   ├── contexts/                      # Contextos React
│   │   └── AuthContext.tsx           # Contexto de autenticação
│   │
│   ├── pages/                         # Páginas da aplicação
│   │   ├── AdministradorasManagement.tsx  # Gerenciamento de Administradoras
│   │   ├── BancoManagement.tsx       # Gerenciamento de Bancos
│   │   ├── Dashboard.tsx             # Página principal
│   │   ├── Login.tsx                 # Tela de login/cadastro
│   │   └── UserManagement.tsx        # Gerenciamento de usuários
│   │
│   ├── styles/                        # Estilos compartilhados
│   │   └── tableStyles.ts            # Estilos de tabelas
│   │
│   ├── App.css                        # Estilos globais
│   ├── App.tsx                        # Componente raiz
│   ├── index.css                      # Estilos base + Tailwind
│   ├── index.tsx                      # Entry point
│   └── theme.ts                       # Tema Material-UI
│
├── Docs/                              # Documentação
│   └── README.md                      # Este arquivo
│
├── .env.example                       # Exemplo de variáveis de ambiente
├── firestore.rules                    # Regras de segurança do Firestore
├── index.html                         # HTML principal
├── package.json                       # Dependências do projeto
├── postcss.config.js                  # Configuração PostCSS
├── tailwind.config.js                 # Configuração Tailwind CSS
├── tsconfig.json                      # Configuração TypeScript
└── vite.config.js                     # Configuração Vite
```

---

## 🛠️ Tecnologias Utilizadas

### Frontend
- **React 18.2.0** - Biblioteca UI
- **TypeScript 4.7.4** - Tipagem estática
- **Vite 3.0.4** - Build tool e dev server

### UI Framework
- **Material-UI 7.3.6** - Componentes UI
- **Material Icons** - Ícones modernos
- **Tailwind CSS 4.1.18** - Utility-first CSS
- **Emotion** - CSS-in-JS

### Backend & Autenticação
- **Firebase 12.7.0**
  - Authentication - Autenticação de usuários
  - Firestore - Banco de dados NoSQL
  - Storage - Armazenamento de arquivos

---

## ⚙️ Funcionalidades

### Sistema de Autenticação
- ✅ Login com email/senha
- ✅ Cadastro de nova empresa (multi-tenant)
- ✅ Criação automática de usuário administrador
- ✅ Logout seguro
- ✅ Proteção de rotas

### Gerenciamento de Usuários
- ✅ CRUD completo de usuários
- ✅ Atribuição de roles (admin, user, manager)
- ✅ Controle granular de permissões por rota
- ✅ Ativação/Desativação de usuários
- ✅ Interface com tabela responsiva e compacta

### Gerenciamento de Administradoras
- ✅ CRUD completo de administradoras
- ✅ Sistema de abas para dados principais e contatos
- ✅ Gerenciamento de múltiplos contatos por administradora
- ✅ Endereço completo com validação de CEP
- ✅ Controle de status (ativo/inativo)
- ✅ Interface moderna com Material-UI
- ✅ Tabelas compactas (`size="small"`)

### Gerenciamento de Bancos (NOVO)
- ✅ CRUD completo de contas bancárias
- ✅ Cadastro de informações bancárias:
  - Número do banco
  - Nome do banco
  - Agência
  - Conta corrente
  - Nome do titular
  - Status (ativo/inativo)
  - Observações
- ✅ Visualização detalhada de contas
- ✅ Confirmação de exclusão
- ✅ Interface responsiva e compacta
- ✅ Proteção por permissões

### Dashboard
- ✅ AppBar com navegação completa
- ✅ 12 módulos principais:
  1. **Início** - Dashboard principal
  2. **Clientes** - Gestão de clientes
  3. **Agenda Técnica** - Agendamentos e OS
  4. **Área Técnica** - Técnicos e equipamentos
  5. **Contratos** - Gestão contratual
  6. **Comercial** - Vendas e propostas
  7. **Financeiro** - Contas e fluxo de caixa
  8. **Compras** - Pedidos e fornecedores
  9. **Produtos** - Catálogo de produtos
  10. **Estoque** - Controle de estoque
  11. **Relatórios** - Relatórios gerenciais
  12. **Configurações** - Configurações do sistema

---

## 🔐 Autenticação e Permissões

### AuthContext

Contexto global que gerencia:
- Estado de autenticação do usuário
- Dados do usuário logado
- Funções de login/logout/cadastro
- Verificação de permissões

**Interface do Contexto:**
```typescript
interface AuthContextType {
  user: User | null;
  userData: UserData | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, nome: string, empresaId: string) => Promise<void>;
  createCompany: (data: CreateCompanyData) => Promise<void>;
  signOut: () => Promise<void>;
  hasPermission: (rota: string) => boolean;
  updateUserPermissions: (userId: string, rotas: string[]) => Promise<void>;
}
```

### Estrutura de Dados do Usuário

**Coleção Firestore: `usuarios`**
```typescript
{
  email: string;
  nome: string;
  empresaId: string;
  role: 'admin' | 'user' | 'manager';
  rotasPermitidas: string[];  // Array de rotas autorizadas
  ativo: boolean;
  criadoEm: Timestamp;
}
```

### Rotas Protegidas do Sistema

O sistema possui controle granular de permissões para as seguintes rotas:

```typescript
const ROTAS_DISPONIVEIS = [
  '/dashboard',
  '/clientes',
  '/clientes/novo',
  '/clientes/lista',
  '/agenda',
  '/agenda/visualizar',
  '/agenda/abertura-chamado',
  '/agenda/ordens-servico',
  '/agenda/area-tecnica',
  '/contratos',
  '/contratos/lista',
  '/contratos/novo',
  '/contratos/comodato',
  '/contratos/sem-pecas',
  '/contratos/com-pecas',
  '/contratos/ativos',
  '/contratos/cancelados',
  '/comercial',
  '/comercial/propostas',
  '/comercial/orcamentos',
  '/comercial/vendas',
  '/financeiro',
  '/financeiro/contas-receber',
  '/financeiro/contas-pagar',
  '/financeiro/fluxo-caixa',
  '/financeiro/boleto',
  '/financeiro/nota-fiscal',
  '/produtos',
  '/produtos/catalogo',
  '/produtos/novo',
  '/produtos/compras',
  '/produtos/fornecedores',
  '/produtos/estoque',
  '/relatorios',
  '/relatorios/financeiro',
  '/relatorios/clientes',
  '/relatorios/vendas',
  '/relatorios/tecnico',
  '/configuracoes',
  '/configuracoes/usuarios',
  '/configuracoes/administradoras',
  '/configuracoes/administradoras/novo',
  '/configuracoes/administradoras/editar',
  '/configuracoes/administradoras/visualizar',
  '/configuracoes/administradoras/contatos',
  '/configuracoes/banco',
];
```

### Sistema de Permissões

- Cada rota pode ser protegida individualmente
- Permissões armazenadas no array `rotasPermitidas` do usuário
- Verificação em tempo real via `hasPermission(rota)`
- Administradores têm acesso total ao sistema

---

## 🧩 Componentes

### Layout.tsx
**Localização:** `src/components/Layout.tsx`

**Responsabilidade:** 
- Componente de layout compartilhado por todas as páginas
- Contém AppBar com navegação global
- 12 menus principais com submenus dropdown
- Menu de usuário com perfil e logout
- Container para conteúdo das páginas
- Define cor padrão de cabeçalho de tabelas (`TABLE_HEADER_BG_COLOR`)

**Props:**
```typescript
interface LayoutProps {
  children: ReactNode;        // Conteúdo da página
  onNavigate?: (page: string) => void;  // Callback para navegação
}
```

**Constantes exportadas:**
```typescript
export const TABLE_HEADER_BG_COLOR = '#e3f2fd'; // Azul claro para cabeçalhos
```

**Vantagens:**
- ✅ Reutilizável em todas as páginas
- ✅ Mantém navegação consistente
- ✅ Facilita manutenção dos menus
- ✅ Centraliza lógica de navegação
- ✅ Padronização visual de tabelas

### ProtectedRoute.tsx
**Localização:** `src/components/ProtectedRoute.tsx`

**Responsabilidade:**
- Proteger rotas baseado em permissões
- Verificar se usuário tem acesso à rota
- Exibir mensagem de acesso negado quando necessário

**Props:**
```typescript
interface ProtectedRouteProps {
  children: ReactNode;
  requiredRoute: string;  // Rota necessária para acesso
}
```

**Uso:**
```tsx
<ProtectedRoute requiredRoute="/configuracoes/banco">
  <BancoManagement />
</ProtectedRoute>
```

### FirebaseStatus
**Localização:** `src/components/FirebaseStatus.tsx`

Componente para verificar status de conexão com Firebase.

---

## 📄 Páginas

### Login.tsx
**Localização:** `src/pages/Login.tsx`

**Funcionalidades:**
- Toggle entre login e cadastro de empresa
- Formulário de login (email + senha)
- Formulário de cadastro completo:
  - Nome da empresa
  - Empresa ID (slug único)
  - Dados do administrador (nome, email, senha)
- Validações em tempo real
- Design responsivo com Material-UI
- Gradiente moderno com cores do tema

**Fluxo de Cadastro:**
1. Usuário preenche dados da empresa e administrador
2. Sistema cria documento na coleção `EMPRESAS`
3. Sistema cria usuário no Firebase Auth
4. Sistema cria documento do usuário com role 'admin'
5. Todas as rotas são automaticamente permitidas para admin

### Dashboard.tsx
**Localização:** `src/pages/Dashboard.tsx`

**Estrutura:**
- AppBar superior com logo e navegação
- Menu de usuário (avatar com dropdown)
- 12 menus com submenus dropdown
- Área de conteúdo dinâmica
- Cards com métricas principais (compactos)

**Páginas renderizadas:**
- Dashboard principal
- Gerenciamento de Usuários
- Gerenciamento de Administradoras
- Gerenciamento de Bancos

**Cards do Dashboard:**
- Padding reduzido (`p-4` ao invés de `p-6`)
- Espaçamento otimizado entre cards
- Tipografia ajustada para economia de espaço

### UserManagement.tsx
**Localização:** `src/pages/UserManagement.tsx`

**Funcionalidades:**
- Listagem de todos os usuários da empresa
- Filtro por empresa (via empresaId)
- Criação de novos usuários
- Edição de usuários existentes
- Ativação/Desativação de contas
- Gerenciamento de permissões por rota
- Interface com tabela Material-UI
- Tabela compacta (`size="small"`)

**Campos do Formulário:**
- Nome
- Email
- Senha (apenas criação)
- Role (admin/user/manager)
- Status (ativo/inativo)
- Rotas permitidas (checkboxes)

### AdministradorasManagement.tsx
**Localização:** `src/pages/AdministradorasManagement.tsx`

**Funcionalidades:**
- CRUD completo de administradoras
- Sistema de abas (Tabs):
  - **Dados Principais:** Informações da administradora
  - **Contatos:** Lista de contatos vinculados
- Gerenciamento de múltiplos contatos
- Validação de dados
- Busca de endereço por CEP
- Tabela compacta (`size="small"`)

**Estrutura de Dados - Administradora:**
```typescript
interface Administradora {
  id: string;
  codigo: string;
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual?: string;
  inscricaoMunicipal?: string;
  email: string;
  telefone: string;
  celular?: string;
  cep: string;
  endereco: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cidade: string;
  uf: string;
  status: 'ativo' | 'inativo';
  observacao?: string;
}
```

**Estrutura de Dados - Contato:**
```typescript
interface Contato {
  id: string;
  nome: string;
  cargo: string;
  email: string;
  telefone: string;
  celular?: string;
  observacao?: string;
}
```

### BancoManagement.tsx (NOVO)
**Localização:** `src/pages/BancoManagement.tsx`

**Funcionalidades:**
- CRUD completo de contas bancárias
- Listagem em tabela compacta (`size="small"`)
- Ações disponíveis:
  - ✅ Visualizar detalhes
  - ✅ Editar informações
  - ✅ Excluir conta (com confirmação)
- Formulário de cadastro/edição
- Controle de status (ativo/inativo)
- Modal de edição com altura ajustada (`minHeight: 500px`)
- Proteção por permissões (`/configuracoes/banco`)

**Estrutura de Dados:**
```typescript
interface Banco {
  id: string;
  numeroBanco: string;
  nomeBanco: string;
  agencia: string;
  contaCorrente: string;
  nomeTitular: string;
  status: 'ativo' | 'inativo';
  observacao?: string;
}
```

**Campos do Formulário:**
- Nº do Banco (obrigatório)
- Nome do Banco (obrigatório)
- Agência (obrigatório)
- Conta Corrente (obrigatório)
- Nome do Titular (obrigatório)
- Status (select: ativo/inativo)
- Observação (textarea)

**Coleção Firestore:**
```
EMPRESAS/{empresaId}/bancos/{bancoId}
```

---

## ⚙️ Configurações

### Firebase
**Arquivo:** `src/config/firebase.ts`

Variáveis de ambiente necessárias (`.env`):
```env
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=
```

### Tema Material-UI
**Arquivo:** `src/theme.ts`

**Paleta de Cores:**
- **Primary:** #00c0a3 (turquesa)
- **Secondary:** #80e0d1 (turquesa claro)
- **Background:** #f5f5f5
- **Border Radius:** 8px

### Tailwind CSS
**Arquivo:** `tailwind.config.js`

Configuração personalizada com cores do tema integradas.

---

## 🎨 Padronizações de Interface

### Tabelas
**Padrão adotado:** Todas as tabelas utilizam `size="small"` para layout compacto

**Benefícios:**
- ✅ Melhor aproveitamento de espaço
- ✅ Visualização de mais dados por tela
- ✅ Interface mais moderna e profissional
- ✅ Consistência visual em todo o sistema

**Implementação:**
```tsx
<Table size="small">
  {/* conteúdo da tabela */}
</Table>
```

**Páginas padronizadas:**
- UserManagement
- AdministradorasManagement
- BancoManagement

### Cabeçalhos de Tabela
**Cor padrão:** `#e3f2fd` (azul claro)

**Definição centralizada:**
```typescript
// src/components/Layout.tsx
export const TABLE_HEADER_BG_COLOR = '#e3f2fd';
```

**Uso:**
```tsx
<TableRow sx={{ backgroundColor: TABLE_HEADER_BG_COLOR }}>
  {/* células do cabeçalho */}
</TableRow>
```

### Cards do Dashboard
**Padronizações:**
- Padding reduzido: `p-4` (ao invés de `p-6`)
- Espaçamento entre cards: `spacing={{ xs: 2, sm: 2, md: 3 }}`
- Tipografia de título: `variant="subtitle1"` com `font-semibold`
- Tipografia de valor: `variant="h4"` (ao invés de `h3`)

### Modais
**Boas práticas implementadas:**
- Altura mínima ajustada quando necessário
- Padding superior no DialogContent: `paddingTop: '20px !important'`
- Responsividade com `maxWidth` e `fullWidth`
- Confirmação para ações destrutivas (exclusão)

---

## 🚀 Scripts Disponíveis

```bash
npm run dev      # Inicia servidor de desenvolvimento
npm run build    # Build de produção
npm run preview  # Preview do build
```

---

## 📝 Regras de Segurança Firestore

**Arquivo:** `firestore.rules`

Define as regras de acesso ao banco de dados:
- Usuários autenticados podem ler/escrever seus próprios dados
- Acesso a dados da empresa é restrito aos usuários da mesma empresa
- Validações de schema nos documentos

**Estrutura de coleções:**
```
EMPRESAS/
  {empresaId}/
    ├── documentos/
    ├── administradoras/
    │   └── {administradoraId}/
    │       └── contatos/
    └── bancos/
        └── {bancoId}

usuarios/
  └── {userId}
```

---

## 🔄 Histórico de Alterações

### [20/12/2024]
- ✅ Implementado módulo de Gerenciamento de Bancos
- ✅ Adicionada rota `/configuracoes/banco` às rotas protegidas
- ✅ Padronização de todas as tabelas com `size="small"`
- ✅ Ajuste de altura do modal de edição de Banco
- ✅ Redução de padding dos cards do Dashboard
- ✅ Exportação de `TABLE_HEADER_BG_COLOR` no Layout
- ✅ Documentação completa atualizada

### [18/12/2024]
- ✅ Criado sistema de autenticação completo
- ✅ Implementado AuthContext
- ✅ Criado componente ProtectedRoute
- ✅ Desenvolvido página de Login com cadastro de empresa
- ✅ Desenvolvido Dashboard com 12 módulos
- ✅ Implementado gerenciamento de usuários
- ✅ Implementado gerenciamento de administradoras
- ✅ Sistema de permissões granulares por rota
- ✅ Interface responsiva com Material-UI
- ✅ Integração completa com Firebase

---

## 📌 Próximos Passos

- [ ] Implementar páginas dos 12 módulos
- [ ] Criar sistema de relatórios
- [ ] Adicionar upload de arquivos
- [ ] Implementar notificações em tempo real
- [ ] Adicionar testes unitários
- [ ] Implementar PWA
- [ ] Adicionar modo escuro
- [ ] Integração com APIs bancárias
- [ ] Sistema de backup automático

---

## 🔧 Manutenção e Boas Práticas

### Ao adicionar novos módulos:
1. Criar página em `src/pages/`
2. Adicionar rota em `ROTAS_DISPONIVEIS` no `AuthContext.tsx`
3. Proteger com `<ProtectedRoute requiredRoute="/rota">`
4. Usar `TABLE_HEADER_BG_COLOR` para cabeçalhos de tabela
5. Usar `size="small"` em todas as tabelas
6. Atualizar documentação

### Padrões de código:
- TypeScript strict mode
- Componentes funcionais com hooks
- Material-UI para componentes
- Tailwind para utilitários CSS
- Firestore para persistência
- Context API para estado global

---

**Desenvolvido com ❤️ usando React + TypeScript + Firebase**
